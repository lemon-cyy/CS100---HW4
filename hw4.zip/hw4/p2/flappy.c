#include "flappy.h"

void advancePipes(Game *game, float dt) {
    /* TODO 1: Move every pipe left by PIPE_SPEED * dt. Then visit the slots
     * in array order; if a pipe's right edge is <= 0, call recyclePipe. */
    for (int i = 0; i < PIPE_COUNT; i++) {
        game->m_pipes[i].m_x -= PIPE_SPEED * dt;
    }
    for (int i = 0; i < PIPE_COUNT; i++) {
        if (game->m_pipes[i].m_x + PIPE_WIDTH <= 0.0f) {
            recyclePipe(game, i);
        }
    }
}

bool birdHitsObstacle(const Game *game) {
    Box bird = gameBirdBox(game);
    if (bird.m_y < 0.0f || bird.m_y + bird.m_height > (float)FLOOR_Y) {
        return true;
    }
    for (int i = 0; i < PIPE_COUNT; ++i) {
        const Pipe *pipe = &game->m_pipes[i];
        Box top = {pipe->m_x, 0.0f, PIPE_WIDTH, pipe->m_gap_y};
        float bottom_y = pipe->m_gap_y + PIPE_GAP_HEIGHT;
        Box bottom = {pipe->m_x, bottom_y, PIPE_WIDTH, (float)FLOOR_Y - bottom_y};
        if (boxesOverlap(bird, top) || boxesOverlap(bird, bottom)) {
            return true;
        }
    }
    return false;
}

int scorePassedPipes(Game *game) {
    /* TODO 3: A pipe scores once when its right edge is strictly left of
     * BIRD_X. Mark it scored, add to m_score, and return this call's count. */
    int earned = 0;
    for (int i = 0; i < PIPE_COUNT; i++) {
        Pipe *pipe = &game->m_pipes[i];
        if (!pipe->m_scored && pipe->m_x + PIPE_WIDTH < (float)BIRD_X) {
            pipe->m_scored = true;
            ++game->m_score;
            ++earned;
        }
    }
    return earned;
}

unsigned int nextRandom(unsigned int seed) {
    /* TODO: Keep one static unsigned int state, initially RANDOM_INITIAL_SEED.
     * A positive seed resets it modulo RANDOM_MODULUS. Then take one
     * recurrence step and return the new state. Zero continues the sequence. */
    static unsigned int state = RANDOM_INITIAL_SEED;
    if (seed > 0) {
        state = seed % RANDOM_MODULUS;
    }
    state = (RANDOM_MULTIPLIER * state + RANDOM_INCREMENT) % RANDOM_MODULUS;
    return state;
}
