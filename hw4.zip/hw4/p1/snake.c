#include "snake.h"

bool snakeInit(Snake *snake, int rows, int cols, size_t length) {
    /* TODO: Make a ring. Start in the middle, facing right.
     * On failure, free any nodes already made and leave an empty snake. */
    *snake = (Snake){0};
    if (rows < MIN_BOARD_SIZE || cols < MIN_BOARD_SIZE || length == 0) {
        return false;
    }
    if ((long)length + BOARD_WALL_THICKNESS > cols - BOARD_WALL_THICKNESS) {
        return false;
    }
    int startRow = rows / 2;
    int headCol = cols / 2;
    SnakeNode *head = NULL, *tail = NULL;
    size_t made = 0;
    for (size_t i = 0; i < length; i++) {
        SnakeNode *node = malloc(sizeof *node);
        if (!node) {
            SnakeNode *p = head;
            for (size_t k = 0; k < made; k++) {
                SnakeNode *next = p->m_next;
                free(p);
                p = next;
            }
            *snake = (Snake){0};
            return false;
        }
        node->m_pos = (Coord){startRow, headCol - (int)i};
        node->m_next = NULL;
        if (!head) {
            head = node;
            tail = node;
        } else {
            node->m_next = head;
            tail->m_next = node;
            tail = node;
        }
        made++;
    }
    if (length == 1) {
        head->m_next = head;
    }
    snake->m_head = head;
    snake->m_length = length;
    snake->m_direction = DIR_RIGHT;
    snake->m_rows = rows;
    snake->m_cols = cols;
    return true;
}

Coord snakeNextPosition(const Snake *snake, Direction requested) {
    /* TODO: Return the next head position. Do not change the snake.
     * Ignore a turn straight back when the snake has more than one node. */
    if (!snake || !snake->m_head) {
        return (Coord){0};
    }
    Direction d = resolveDirection(snake, requested);
    return stepCoord(snake->m_head->m_pos, d);
}

bool snakeContains(const Snake *snake, Coord pos) {
    /* TODO: Check every node once. The ring does not end at NULL. */
    if (!snake || !snake->m_head) {
        return false;
    }
    const SnakeNode *node = snake->m_head;
    for (size_t i = 0; i < snake->m_length; i++) {
        if (node->m_pos.m_row == pos.m_row && node->m_pos.m_col == pos.m_col) {
            return true;
        }
        node = node->m_next;
    }
    return false;
}

StepResult snakeStep(Snake *snake, Direction requested, bool grow) {
    /* TODO: Check the next position before changing the ring.
     * Reuse the tail on a normal move; add one node when growing.
     * A normal move may enter the old tail's cell. A growing move may not. */
    if (!snake || !snake->m_head) {
        return STEP_WALL;
    }
    Direction d = resolveDirection(snake, requested);
    Coord next = stepCoord(snake->m_head->m_pos, d);
    if (next.m_row <= 0 || next.m_row >= snake->m_rows - 1 || next.m_col <= 0 ||
        next.m_col >= snake->m_cols - 1) {
        return STEP_WALL;
    }
    const SnakeNode *tail = snake->m_head->m_next;
    const SnakeNode *node = snake->m_head;
    for (size_t i = 0; i < snake->m_length; i++) {
        if (node->m_pos.m_row == next.m_row && node->m_pos.m_col == next.m_col) {
            bool enterable = !grow && (node == tail);
            if (!enterable) {
                return STEP_SELF;
            }
        }
        node = node->m_next;
    }
    if (grow) {
        SnakeNode *newHead = malloc(sizeof *newHead);
        if (!newHead) {
            return STEP_NO_MEMORY;
        }
        SnakeNode *preHead = snake->m_head;
        for (size_t i = 0; i < snake->m_length; ++i) {
            if (preHead->m_next == snake->m_head) {
                break;
            }
            preHead = preHead->m_next;
        }
        newHead->m_pos = next;
        newHead->m_next = snake->m_head;
        preHead->m_next = newHead;
        snake->m_head = newHead;
        snake->m_length += 1;
    } else {
        SnakeNode *oldTail = snake->m_head->m_next;
        oldTail->m_pos = next;
        snake->m_head = oldTail;
    }
    snake->m_direction = d;
    return STEP_OK;
}

void snakeDestroy(Snake *snake) {
    if (!snake)
        return;
    SnakeNode *node = snake->m_head;
    for (size_t i = 0; i < snake->m_length && node; i++) {
        SnakeNode *next = node->m_next;
        free(node);
        node = next;
    }
    *snake = (Snake){0};
}

unsigned int nextRandom(unsigned int seed) {
    /* TODO: Keep one static unsigned int state, initially RANDOM_INITIAL_SEED.
     * A positive seed resets it modulo RANDOM_MODULUS. Then take one
     * recurrence step and return the new state. Zero continues the sequence. */
    static unsigned int state = RANDOM_INITIAL_SEED;
    if (seed > 0) {
        state = seed % RANDOM_MODULUS;
    }
    state = (RANDOM_MULTIPLIER * state + RANDOM_INCREMENT) % RANDOM_MODULUS;
    return state;
}
